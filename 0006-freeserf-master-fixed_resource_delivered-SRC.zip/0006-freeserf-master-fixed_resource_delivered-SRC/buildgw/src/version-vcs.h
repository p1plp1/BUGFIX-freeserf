#ifndef VERSION_VCS_H
#define VERSION_VCS_H

#define VERSION_VCS ""

#endif /* VERSION_VCS_H */
