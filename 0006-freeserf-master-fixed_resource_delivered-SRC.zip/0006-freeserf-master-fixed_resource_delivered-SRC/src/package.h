#ifndef SRC_PACKAGE_H_

#define SRC_PACKAGE_H_ 

#define PACKAGE_NAME ""

#define PACKAGE_TARNAME ""

#define PACKAGE_VERSION ""

#define PACKAGE_STRING ""

//#define PACKAGE_BUGREPORT ""

#define PACKAGE_URL ""


#endif 

